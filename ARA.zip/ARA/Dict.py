# -*- coding: utf-8 -*-
"""
@author: 배준호
"""

import numpy as np

class Dict:
    def __init__(self, name, idx, eigen):
        self.name = name
        self.indexOfSelf = idx
        self.eigenVal = eigen
    
        self.r = 0.0
        self.c = 0.0
        self.v = 1.0
        self.gap = 0
    
        self.alpha = 1.0
        self.beta = 10.0
        self.epsilon = 1e-6
        self.rebound = 100
        self.threshold = 25
    
        self.name_vector = self._string_to_vector(self.name)

    def forward(self, dest: str):
        dest_vector = self._string_to_vector(dest)
        sim = self._compute_similarity(dest_vector, self.name_vector)
    
        r_sig = self._sigmoid(self.r)
        c_sig = self._sigmoid(self.c)
    
        numerator = np.exp(self.alpha * r_sig)
        denominator = np.log(1 + self.beta * c_sig)
        weight = numerator / (denominator + self.epsilon)
    
        return sim * weight * self.v, self.indexOfSelf, self.eigenVal, self.name, np.mean(self.name_vector)

    def fireDic(self):
        self.r += 0.8 + 0.2 * np.random.normal()
        self.c = max(0.0, self.c - 20)
        if self.gap >= self.threshold:
            self.c = max(0.0, self.c - self.rebound)
        self.gap = 0

    def passDic(self):
        self.r = max(0.0, self.r - 0.001)
        self.c += 0.0001
        self.gap += 1
        
    def simility(self, token):
        return self._compute_similarity(self._string_to_vector(token), self.name_vector)
    
    def get_MeanVec(self, token):
        return np.mean(self.name_vector)

    def _compute_similarity(self, vec1, vec2):
        vec1, vec2 = self._pad_vectors(vec1, vec2)
    
        cosine = self._cosine_similarity(vec1, vec2)
        jaccard = self._jaccard_similarity(set(vec1), set(vec2))
        lcs = self._lcs_similarity(vec1, vec2)
    
        return (cosine + lcs + jaccard) / 3

    def _string_to_vector(self, text: str):
        vec = []
        for i, ch in enumerate(text, 1):
            code = self._char_to_scalar(ch)
            val = self._weight_function(code, i)
            vec.append(val)
        return vec

    def _pad_vectors(self, v1, v2):
        max_len = max(len(v1), len(v2))
        v1 = np.pad(v1, (0, max_len - len(v1)), mode='constant')
        v2 = np.pad(v2, (0, max_len - len(v2)), mode='constant')
        return v1, v2

    def _char_to_scalar(self, ch):
        return np.log(ord(ch) + 1) ** (2 - 2 ** (-ord(ch) / 128))

    def _weight_function(self, code, idx):
        return ((np.exp(-0.125 * idx)) + 0.125 * np.log(5 * idx)) * idx * code

    def _sigmoid(self, x):
        return 1.0 / (1 + np.exp(-x))

    def _cosine_similarity(self, v1, v2):
        dot = np.dot(v1, v2)
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)
        return dot / (norm1 * norm2) if norm1 and norm2 else 0.0

    def _jaccard_similarity(self, a, b):
        sa, sb = set(a), set(b)
        union = sa | sb
        return len(sa & sb) / len(union) if union else 0.0

    def _lcs_similarity(self, v1, v2):
        n, m = len(v1), len(v2)
        dp = [[0] * (m + 1) for _ in range(n + 1)]
        for i in range(n):
            for j in range(m):
                if v1[i] == v2[j]:
                    dp[i + 1][j + 1] = dp[i][j] + 1
        max_lcs = max(max(row) for row in dp)
        return max_lcs / max(n, m) if max(n, m) else 0.0
