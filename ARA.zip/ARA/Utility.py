# -*- coding: utf-8 -*-
"""
@author: 배준호
"""

import os
import re
import random
import sys

class Utility:

    @staticmethod
    def loadTextIndex(folder_path, start=0, count=10, pattern=r'^(\d+)_'):
        files = []
        for name in os.listdir(folder_path):
            match = re.match(pattern, name)
            if match:
                index = int(match.group(1))
                files.append((index, name))

        files.sort(key=lambda x: x[0])  # 인덱스 기준 정렬
        selected_files = files[start:start + count]

        data = []
        for _, filename in selected_files:
            path = os.path.join(folder_path, filename)
            with open(path, encoding='utf-8') as f:
                data.append(f.read())
        return data

    @staticmethod
    def splitChunkData(texts, chunk_size=5):
        sentences = []
        splitter = re.compile(r'(?<=[.!?])\s+')
        for text in texts:
            chunks = splitter.split(text.strip())
            sentences.extend([s.strip() for s in chunks if s.strip()])

        random.shuffle(sentences)

        grouped = []
        for i in range(0, len(sentences), chunk_size):
            chunk = sentences[i:i + chunk_size]
            grouped.append(" ".join(chunk))
        return grouped

    @staticmethod
    def print_single_progress(epoch, file_now, file_total, batch_now, batch_total, loss=None):
        file_percent = int(((file_now) / file_total) * 100)
        batch_percent = int(((batch_now) / batch_total) * 100)
    
        bar_width = 32
    
        file_bar_len = min(bar_width, int(bar_width * file_percent / 100))
        batch_bar_len = min(bar_width, int(bar_width * batch_percent / 100))
    
        file_bar = '=' * file_bar_len + '>' + ' ' * (bar_width - file_bar_len - 1)
        batch_bar = '=' * batch_bar_len + '>' + ' ' * (bar_width - batch_bar_len - 1)
    
        line = (
            f"\rEpoch {epoch:<2} || "
            f"Train [{batch_bar}] {batch_percent:3d}% ({batch_now:3d}/{batch_total})\t||\t"
            f"Text  [{file_bar}] {file_percent:3d}% ({file_now:3d}/{file_total})\t"
        )
    
        if loss is not None:
            line += f" || LOSS = {loss:.6f}"
            print()
    
        sys.stdout.write(line)
        sys.stdout.flush()
