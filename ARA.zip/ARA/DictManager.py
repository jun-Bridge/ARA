# -*- coding: utf-8 -*-
"""
@author: 배준호
"""
import numpy as np
import pandas as pd
from Tokenizer import Tokenizer
from Dict import Dict
import re

class DictManager:
    def __init__(self):
        self.spell_list, self.spell_cache, self.spell_size, self.spell_eigen = [], [], 0, 1
        self.words_list, self.words_cache, self.words_size, self.words_eigen = [], [], 0, 1
        self.sentence_list, self.sentence_cache, self.sentence_size, self.sentence_eigen = [], [], 0, 1
        self.paragraph_list, self.paragraph_cache, self.paragraph_size, self.paragraph_eigen = [], [], 0, 1

        self.add_token("spell", "A", 0)
        self.add_token("words", "A", 0)
        self.add_token("sentence", "A", 0)
        self.add_token("paragraph", "A", 0)

        self.tokenizer = Tokenizer()

    def translate(self, text):
        tokens = self.tokenizer.tokenize(text)
        self.spell_output = self._match_spell(tokens["spell"])
        self.words_output = self._match_words(tokens["words"])
        self.sentence_output = self._match_sentence(tokens["sentences"])
        self.paragraph_output = self._match_paragraph(tokens["original"])
        return self.paragraph_output, self.sentence_output, self.words_output, self.spell_output

    def _match_spell(self, tokens):
        return self._match_tokens(tokens, self.spell_list, self.spell_cache,
                                  lambda text, eigen: self.add_token("spell", text, eigen),
                                  0.8, 0.4, "spell")

    def _match_words(self, tokens):
        return self._match_tokens(tokens, self.words_list, self.words_cache,
                                  lambda text, eigen: self.add_token("words", text, eigen),
                                  0.9, 0.5, "words")#575

    def _match_sentence(self, sentence_list):
        slices = []
        for sentence in sentence_list:
            slices.extend(self.slice_n_word(sentence))
        result = self._match_tokens(
            slices,
            self.sentence_list,
            self.sentence_cache,
            lambda text, eigen: self.add_token("sentence", text, eigen),
            0.6, 0.35,
            "sentence"
        )
        self.sentence_list = self.delete_by_c(self.sentence_list, 0.008)
        return result

    def _match_paragraph(self, paragraph):
        slices = self.slice_n_sentence(paragraph)
        result = self._match_tokens(slices, self.paragraph_list, self.paragraph_cache,
                                    lambda text, eigen: self.add_token("paragraph", text, eigen),
                                    0.55, 0.3, "paragraph")
        self.paragraph_list = self.delete_by_c(self.paragraph_list, 0.005)
        return result

    def _match_tokens(self, tokens, dict_list, cache_list, add_func, threshold1, threshold2, level):
        result_output = []

        for token in tokens:
            topk = self.get_topk_eigen_from_cache(token, cache_list, K=3)
            fired = False
            max_sim = -1.0
            base_eigen = 0
            touched_ids = set()

            for eigen in topk:
                start = self.get_offset_index_from_dict(dict_list, eigen)
                for i in range(start, len(dict_list)):
                    d = dict_list[i]
                    if d.eigenVal > eigen + 0.5:
                        break
                    if id(d) in touched_ids:
                        continue

                    sim = d.simility(token)
                    touched_ids.add(id(d))

                    if sim >= threshold1:
                        d.fireDic()
                        tmp = d.forward(token)
                        self.insert_output(result_output, (tmp[0], tmp[1], tmp[2], tmp[3], tmp[4]))
                        fired = True
                    else:
                        d.passDic()
                        if sim > max_sim:
                            max_sim = sim
                            base_eigen = d.eigenVal

            for d in dict_list:
                if id(d) not in touched_ids:
                    d.passDic()

            if fired:
                continue

            if max_sim < 0:
                new_eigen = self.get_eigen(level, 0, 0, threshold2)
            else:
                new_eigen = self.get_eigen(level, max_sim, base_eigen, threshold2)

            add_func(token, new_eigen)
            self.insert_output(result_output, (1.4 + 0.01 * np.random.normal(), len(dict_list), new_eigen, token, 0.0))

        return result_output

    def get_topk_eigen_from_cache(self, token, cache_list, K=5):
        scored = [(d.simility(token), d.eigenVal) for d in cache_list]
        scored.sort(key=lambda x: x[0], reverse=True)
        topk, seen = [], set()
        for sim, eigen in scored:
            if eigen not in seen:
                topk.append(eigen)
                seen.add(eigen)
            if len(topk) >= K:
                break
        return topk

    def get_offset_index_from_dict(self, dict_list, eigen):
        lower_bound = eigen - 0.55
        for idx, d in enumerate(dict_list):
            if d.eigenVal >= lower_bound:
                return idx
        return len(dict_list)

    def insert_sorted_by_eigen(self, list_obj, dic):
        for i, existing in enumerate(list_obj):
            if dic.eigenVal < existing.eigenVal:
                list_obj.insert(i, dic)
                return
        list_obj.append(dic)

    def insert_output(self, list_output, output):
        score = output[0]
        for i, item in enumerate(list_output):
            if score > item[0]:
                list_output.insert(i, output)
                return
        list_output.append(output)

    def add_token(self, level, text, eigen):
        level_map = {
            "spell": (self.spell_list, self.spell_cache, "spell_size"),
            "words": (self.words_list, self.words_cache, "words_size"),
            "sentence": (self.sentence_list, self.sentence_cache, "sentence_size"),
            "paragraph": (self.paragraph_list, self.paragraph_cache, "paragraph_size")
        }
        list_ref, cache_ref, size_name = level_map[level]
        dic = Dict(text, getattr(self, size_name), eigen)
        self.insert_sorted_by_eigen(list_ref, dic)
        setattr(self, size_name, getattr(self, size_name) + 1)
        if eigen % 1 == 0:
            self.insert_sorted_by_eigen(cache_ref, dic)

    def get_eigen(self, level, sim, origin, threshold):
        eigen_map = {
            "spell": self.spell_eigen,
            "words": self.words_eigen,
            "sentence": self.sentence_eigen,
            "paragraph": self.paragraph_eigen
        }
        limit_map = {
            "spell": 128,
            "words": 1024,
            "sentence": 512,
            "paragraph": 512
        }

        if sim <= threshold:
            if eigen_map[level] >= limit_map[level]:
                print(f"[ERROR][Eigen Overflow] in {level}")
                return -1
            val = eigen_map[level]
            setattr(self, f"{level}_eigen", val + 1)
            return val
        else:
            return origin + (np.random.normal() / sim * 0.06)

    def delete_by_c(self, dict_list, c_threshold):
        return [
            d for d in dict_list
            if d.c < c_threshold or (d.eigenVal % 1 == 0)  # 정수 eigen은 무조건 보존
        ]

    def slice_n_word(self, sentence: str, n: int = 3):
        tokens = sentence.strip().split()
        return [" ".join(tokens[i:i+n]) for i in range(len(tokens) - n + 1)]

    def slice_n_sentence(self, paragraph: list[str], n: int = 3):
        paragraph = paragraph[0]
        paragraph = paragraph.replace("...", ".")
        
        sentences = re.split(r'(?<=[.!?~\\-])\s+|\n+', paragraph)
        sentences = [s.strip() for s in sentences if s.strip()]
    
        return [" ".join(sentences[i:i+n]) for i in range(len(sentences) - n + 1)]

    def rebuild_cache(self):
        for level in ["spell", "words", "sentence", "paragraph"]:
            list_attr = getattr(self, f"{level}_list")
            cache = [d for d in list_attr if d.eigenVal % 1 == 0]
            cache.sort(key=lambda d: d.eigenVal)
            setattr(self, f"{level}_cache", cache)

    def save(self, prefix="ribosome"):
        for level in ["spell", "words", "sentence", "paragraph"]:
            self._save_dict(getattr(self, f"{level}_list"), f"{prefix}_dict_{level}.xlsx")

    def load(self, prefix="ribosome"):
        for level in ["spell", "words", "sentence", "paragraph"]:
            loaded, size, eigen = self._load_dict(f"{prefix}_dict_{level}.xlsx")
            setattr(self, f"{level}_list", loaded)
            setattr(self, f"{level}_size", size)
            setattr(self, f"{level}_eigen", eigen)
        self.rebuild_cache()

    def _save_dict(self, dict_list, filename):
        df = pd.DataFrame([{
            "name": d.name,
            "index": d.indexOfSelf,
            "eigen": d.eigenVal,
            "r": d.r, "c": d.c, "v": d.v,
            "alpha": d.alpha, "beta": d.beta,
            "epsilon": d.epsilon, "rebound": d.rebound,
            "gap": d.gap, "threshold": d.threshold
        } for d in dict_list])
        df.to_excel(filename, index=False)
        print(f" {filename} 저장 완료 — {len(dict_list)}개")

    def _load_dict(self, filename):
        df = pd.read_excel(filename)
        dict_list = []
        for _, row in df.iterrows():
            d = Dict(str(row["name"]), int(row["index"]), float(row["eigen"]))
            d.r = float(row["r"])
            d.c = float(row["c"])
            d.v = float(row["v"])
            d.alpha = float(row["alpha"])
            d.beta = float(row["beta"])
            d.epsilon = float(row["epsilon"])
            d.rebound = float(row["rebound"])
            d.gap = int(row["gap"])
            d.threshold = int(row["threshold"])
            dict_list.append(d)
        self.fix_ribosome_index(dict_list)
        size = max(d.indexOfSelf for d in dict_list) + 1
        eigen = int(np.floor(max(d.eigenVal for d in dict_list))) + 1
        return dict_list, size, eigen

    def fix_ribosome_index(self, dict_list):
        for i, d in enumerate(dict_list):
            d.indexOfSelf = i
