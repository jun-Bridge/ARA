# -*- coding: utf-8 -*-
"""
@author: 배준호
"""
import numpy as np
import pandas as pd
from Tokenizer import Tokenizer
from Dict import Dict

class DictManager:
    def __init__(self):
        self.dicts = {
            "spell": {"list": [], "cache": [], "size": 0, "eigen": 1},
            "words": {"list": [], "cache": [], "size": 0, "eigen": 1},
            "sentence": {"list": [], "cache": [], "size": 0, "eigen": 1},
            "paragraph": {"list": [], "cache": [], "size": 0, "eigen": 1}
        }

        for level in self.dicts:
            self.add_token(level, "A", 0)

        self.tokenizer = Tokenizer()

    def translate(self, text):
        tokens = self.tokenizer.tokenize(text)
        self.spell_output = self._translate_level("spell", tokens["spell"])
        self.words_output = self._translate_level("words", tokens["words"])
        self.sentence_output = self._translate_level("sentence", tokens["sentences"])
        self.paragraph_output = self._translate_level("paragraph", tokens["original"])
        return self.paragraph_output, self.sentence_output, self.words_output, self.spell_output

    def _translate_level(self, level, tokens):
        thresholds = {
            "spell": (0.8, 0.4),
            "words": (0.9, 0.575),
            "sentence": (0.475, 0.25),
            "paragraph": (0.475, 0.25)
        }

        return self._match_tokens(
            tokens,
            self.dicts[level]["list"],
            self.dicts[level]["cache"],
            lambda text, eigen: self.add_token(level, text, eigen),
            *thresholds[level],
            level
        )

    def _match_tokens(self, tokens, dict_list, cache_list, add_func, threshold1, threshold2, level):
        result_output = []
    
        for token in tokens:
            topk = self.get_topk_eigen_from_cache(token, cache_list, K=3)
            fired = False
            max_sim = -1.0
            base_eigen = 0
            touched_ids = set()
    
            for eigen in topk:
                start = self.get_offset_index_from_dict(dict_list, eigen)
                for i in range(start, len(dict_list)):
                    d = dict_list[i]
                    if d.eigenVal > eigen + 0.5:
                        break
                    if id(d) in touched_ids:
                        continue
    
                    sim = d.simility(token)
                    touched_ids.add(id(d))
    
                    if sim >= threshold1:
                        d.fireDic()
                        tmp = d.forward(token)
                        self.insert_output(result_output, (tmp[0], tmp[1], tmp[2], tmp[3], tmp[4]))
                        fired = True
                    else:
                        d.passDic()
                        if sim > max_sim:
                            max_sim = sim
                            base_eigen = d.eigenVal
    
            for d in dict_list:
                if id(d) not in touched_ids:
                    d.passDic()
    
            if fired:
                continue
    
            if max_sim < 0:
                new_eigen = self.get_eigen(self.dicts[level], 0, 0, threshold2, level)
            else:
                new_eigen = self.get_eigen(self.dicts[level], max_sim, base_eigen, threshold2, level)
    
            add_func(token, new_eigen)
            self.insert_output(result_output, (1.4 + 0.01 * np.random.normal(), len(dict_list), new_eigen, token, 0.0))
    
        return result_output

    def get_topk_eigen_from_cache(self, token, cache_list, K=5):
        scored = [(d.simility(token), d.eigenVal) for d in cache_list]
        scored.sort(key=lambda x: x[0], reverse=True)

        topk = []
        seen = set()
        for sim, eigen in scored:
            if eigen not in seen:
                topk.append(eigen)
                seen.add(eigen)
            if len(topk) >= K:
                break
        return topk

    def get_offset_index_from_dict(self, dict_list, eigen):
        lower_bound = eigen - 0.55
        for idx, d in enumerate(dict_list):
            if d.eigenVal >= lower_bound:
                return idx
        return len(dict_list)
    
    def insert_sorted_by_eigen(self, list_obj, dic):
        for i, existing in enumerate(list_obj):
            if dic.eigenVal < existing.eigenVal:
                list_obj.insert(i, dic)
                return
        list_obj.append(dic)


    def insert_output(self, list_output, output):
        score = output[0]
        for i, item in enumerate(list_output):
            if score > item[0]:
                list_output.insert(i, output)
                return
        list_output.append(output)
            
    def add_token(self, level, text, eigen):
        meta = self.dicts[level]
        dic = Dict(text, meta["size"], eigen)
        self.insert_sorted_by_eigen(meta["list"], dic)
        meta["size"] += 1
        if eigen % 1 == 0:
            self.insert_sorted_by_eigen(meta["cache"], dic)

    def get_eigen(self, meta, sim, origin, threshold, level):
        if sim <= threshold:
            limit = {"spell": 128, "words": 1408, "sentence": 1024, "paragraph": 1024}[level]
            offset = self.isAbleEigen(meta["eigen"], limit)
            if offset == -1:
                print(f"[ERROR][Eigen Overflow] in {level}")
            meta["eigen"] += 1
            return offset
        else:
            return origin + (np.random.normal() / sim * 0.06)

    def isAbleEigen(self, eigen, limit):
        return eigen if eigen < limit else -1

    def rebuild_cache(self):
        for level in self.dicts:
            cache = [d for d in self.dicts[level]["list"] if d.eigenVal % 1 == 0]
            cache.sort(key=lambda d: d.eigenVal)
            self.dicts[level]["cache"] = cache


    def save(self, prefix="ribosome"):
        for level in self.dicts:
            self._save_dict(self.dicts[level]["list"], f"{prefix}_dict_{level}.xlsx")

    def load(self, prefix="ribosome"):
        for level in self.dicts:
            loaded, size, eigen = self._load_dict(f"{prefix}_dict_{level}.xlsx")
            self.dicts[level]["list"] = loaded
            self.dicts[level]["size"] = size
            self.dicts[level]["eigen"] = eigen
        self.rebuild_cache()


    def _save_dict(self, dict_list, filename):
        df = pd.DataFrame([{
            "name": d.name,
            "index": d.indexOfSelf,
            "eigen": d.eigenVal,
            "r": d.r, "c": d.c, "v": d.v,
            "alpha": d.alpha, "beta": d.beta,
            "epsilon": d.epsilon, "rebound": d.rebound,
            "gap": d.gap, "threshold": d.threshold
        } for d in dict_list])
        df.to_excel(filename, index=False)
        print(f" {filename} 저장 완료 — {len(dict_list)}개")

    def _load_dict(self, filename):
        df = pd.read_excel(filename)
        dict_list = []
        for _, row in df.iterrows():
            d = Dict(str(row["name"]), int(row["index"]), float(row["eigen"]))
            d.r = float(row["r"])
            d.c = float(row["c"])
            d.v = float(row["v"])
            d.alpha = float(row["alpha"])
            d.beta = float(row["beta"])
            d.epsilon = float(row["epsilon"])
            d.rebound = float(row["rebound"])
            d.gap = int(row["gap"])
            d.threshold = int(row["threshold"])
            dict_list.append(d)
        self.fix_ribosome_index(dict_list)
        size = max(d.indexOfSelf for d in dict_list) + 1
        eigen = int(np.floor(max(d.eigenVal for d in dict_list))) + 1
        return dict_list, size, eigen

    def fix_ribosome_index(self, dict_list):
        for i, d in enumerate(dict_list):
            d.indexOfSelf = i
