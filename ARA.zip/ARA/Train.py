# -*- coding: utf-8 -*-
"""
@author: 배준호
"""
from Utility import Utility
import random

class Train:
    def __init__(self, ara, folder, chunk_size=2):
        self.ara = ara             
        self.folder = folder      
        self.chunk_size = chunk_size

    def run(self, epoch=1, offset=0, filesize=100, isShuffle=True, isSlipped=True):
        for ep in range(epoch):
            print(f"\n[Epoch {ep+1}/{epoch}] 시작")
            
            if isSlipped:
                start = offset + ep
            else:
                start = offset
    
            texts = Utility.loadTextIndex(self.folder, start, count=filesize)
            chunks = Utility.splitChunkData(texts, chunk_size=self.chunk_size)
            if isShuffle:
                random.shuffle(chunks)
    
            batch_size = self.ara.buffer.batch_size
            batch_max = len(chunks)
            train_max = (batch_max + batch_size - 1) // batch_size
    
            batch_now = 0
            train_now = 0
    
            for text in chunks:
                result = self.ara.train(text)
                loss = result[0]
    
                batch_now += 1
                if loss is not None:
                    train_now += 1
    
                Utility.print_single_progress(
                    epoch=ep + 1,
                    file_now=batch_now,
                    file_total=batch_max,
                    batch_now=train_now,
                    batch_total=train_max,
                    loss=loss
                )
    
            final = self.ara.buffer.get_final_batch()
            if final is not None:
                encoded = self.ara.encoder.forward(final)
                decoded, loss = self.ara.decoder.forward(encoded, final)
                grad = self.ara.decoder.backward()
                self.ara.encoder.backward(grad)
    
                train_now += 1
    
                Utility.print_single_progress(
                    epoch=ep + 1,
                    file_now=batch_now,
                    file_total=batch_max,
                    batch_now=train_now,
                    batch_total=train_max,
                    loss=loss
                )
    
            print(f"\n[Epoch {ep+1}] 완료 | Total Trains = {train_now} | Last Loss = {loss:.6f}")
    
            print("\n[학습 완료] 모델 저장 중...")
            self.ara.save("ara_model")
