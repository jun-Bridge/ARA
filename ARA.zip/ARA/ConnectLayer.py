# -*- coding: utf-8 -*-
"""
Created on Sat May 24 14:09:06 2025

@author: 배준호
"""

import cupy as cp
from Layer import ReLu, Sigmoid

class ConnectLayer:
    def __init__(self, dic_size, batch_size):
        self.dic_size = dic_size
        self.batch_size = batch_size
        self.current_group = []
        self.buffer = []
        self.Sigmoid = Sigmoid()

    def push(self, dic_output, size, area):
        vec = self.dic2mlp(dic_output, size, area)
        self.current_group.append(vec)

        if len(self.current_group) == self.dic_size:
            full_vec = self.concat(self.current_group)
            self.buffer.append(full_vec)
            self.current_group = []

    def dic2mlp(self, dic, mlp_size, area):
        output = cp.random.normal(loc=0.0, scale=0.01, size=mlp_size)
        next_slot = {}
        for score, index, eigen, name, encode in dic:
            eig = round(eigen)
            base = eig * 4
            if base >= mlp_size - 3:
                continue
            offset = next_slot.get(eig, 0)
            idx = base + offset
            encode = cp.asarray(encode)
            x = score * encode * 0.1
            output[idx] = x #self.Sigmoid.forward(x)
            next_slot[eig] = (offset + 1) % area      
            
        return output

    def is_ready(self):
        return len(self.buffer) >= self.batch_size

    def set_batch(self, size):
        self.batch_size = size

    def get_batch(self):
        if not self.is_ready():
            return None
        batch = cp.stack(self.buffer[:self.batch_size])
        self.buffer = self.buffer[self.batch_size:]
        return batch  # cp.ndarray of shape (batch_size, total_size)

    def get_final_batch(self):
        if not self.buffer:
            return None
        batch = cp.stack(self.buffer)
        self.buffer = []
        return batch  # cp.ndarray of shape (n, total_size)

    def flush(self):
        self.current_group = []
        self.buffer = []

    def size(self):
        return len(self.buffer)
    
#==============================================================================

    @staticmethod
    def concat(vectors):
        """여러 (n, size) 벡터 → (n, total_size)"""
        return cp.concatenate([cp.asarray(v) for v in vectors], axis=-1)

    @staticmethod
    def split(tensor, sizes):
        """(n, total_size) → [(n, s1), (n, s2), ...]"""
        if tensor.ndim == 1:
            tensor = tensor.reshape(1, -1)
        outputs = []
        start = 0
        for size in sizes:
            outputs.append(tensor[:, start:start + size])
            start += size
        return outputs