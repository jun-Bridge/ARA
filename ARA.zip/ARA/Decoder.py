# -*- coding: utf-8 -*-
"""
@author: 배준호
"""

from Layer import Dense, ReLu, Sigmoid, MSE
import cupy as cp
import pickle

class Decoder:
    def __init__(self, buffer):
        self.totalDNet = [
            Dense(256, 1024),
            ReLu(),
            Dense(1024, 2048),
        ]

        self.paragraphDNet = [
            ReLu(),
            Dense(512, 1024),
            Sigmoid(),
            Dense(1024, 1024 * 4)
        ]

        self.sentenceDNet = [
            ReLu(),
            Dense(512, 1024),
            Sigmoid(),
            Dense(1024, 1024 * 4)
        ]

        self.wordsDNet = [
            ReLu(),
            Dense(512, 1024),
            Sigmoid(),
            Dense(1024, 1408 * 4)
        ]

        self.spellsDNet = [
            ReLu(),
            Dense(512, 1024),
            Sigmoid(),
            Dense(1024, 128)
        ]

        self.size = 4
        self.connection = buffer
        self.cost = MSE()

    def forward(self, vecTotal, label):
        self.label = label

        for layer in self.totalDNet:
            vecTotal = layer.forward(vecTotal)

        pragIp, sentIp, wordIp, spellIp = self.connection.split(
            vecTotal, [512, 512, 512, 512]
        )

        for idx in range(self.size):
            pragIp = self.paragraphDNet[idx].forward(pragIp)
            sentIp = self.sentenceDNet[idx].forward(sentIp)
            wordIp = self.wordsDNet[idx].forward(wordIp)
            spellIp = self.spellsDNet[idx].forward(spellIp)

        self.vecOut = self.connection.concat([pragIp, sentIp, wordIp, spellIp])
        loss = self.cost.forward(self.vecOut, label)

        return self.vecOut, loss

    def backward(self):
        delta = self.vecOut - self.label

        deltaParag, deltaSentc, deltaWords, deltaSpell = self.connection.split(
            delta, [1024 * 4, 1024 * 4, 1408 * 4, 128]
        )

        for idx in reversed(range(self.size)):
            deltaSpell = self.spellsDNet[idx].backward(deltaSpell)
            deltaWords = self.wordsDNet[idx].backward(deltaWords)
            deltaSentc = self.sentenceDNet[idx].backward(deltaSentc)
            deltaParag = self.paragraphDNet[idx].backward(deltaParag)

        deltaConcat = self.connection.concat(
            [deltaParag, deltaSentc, deltaWords, deltaSpell]
        )

        for layer in reversed(self.totalDNet):
            deltaConcat = layer.backward(deltaConcat)

        return deltaConcat

    def save(self, path):
        nets = (
            self.totalDNet +
            self.paragraphDNet +
            self.sentenceDNet +
            self.wordsDNet +
            self.spellsDNet
        )
        self._save_weights(nets, path)

    def load(self, path):
        nets = (
            self.totalDNet +
            self.paragraphDNet +
            self.sentenceDNet +
            self.wordsDNet +
            self.spellsDNet
        )
        self._load_weights(nets, path)

    def _save_weights(self, nets, filename):
        weights = []
        for net in nets:
            if isinstance(net, Dense):
                weights.append((
                    cp.asnumpy(net.w),
                    cp.asnumpy(net.b)
                ))
        with open(filename, 'wb') as f:
            pickle.dump(weights, f)
    
    def _load_weights(self, nets, filename):
        with open(filename, 'rb') as f:
            weights = pickle.load(f)
    
        idx = 0
        for net in nets:
            if isinstance(net, Dense):
                w, b = weights[idx]
                net.w = cp.asarray(w)
                net.b = cp.asarray(b)
                idx += 1
