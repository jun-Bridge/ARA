# -*- coding: utf-8 -*-
"""
Created on Sat May 24 13:44:28 2025

@author: 배준호
"""

import re

class Tokenizer:
    def __init__(self):
        self.sentence_splitter = re.compile(r'(?<=[.!?])\s+(?=[A-Z0-9])')
        self.word_cleaner = re.compile(r'^[\W_]+|[\W_]+$')
        self.sentence_filter = re.compile(r'(~|<br|nbsp|\*{2,}|\.{3,}|-{2,})', re.IGNORECASE)

    def tokenize(self, paragraph):
        if not isinstance(paragraph, str):
            raise TypeError("Input must be a string.")

        original = paragraph.strip()

        # 문장 분해 + 정제
        raw_sentences = self.sentence_splitter.split(original)
        sentences = []
        for s in raw_sentences:
            s_clean = s.strip()
            if len(s_clean) >= 5 and not self.sentence_filter.search(s_clean):
                sentences.append(s_clean)

        # 단어 분해
        raw_words = []
        for s in sentences:
            raw_words.extend(s.split())

        # 단어 정제
        word_tokens = [self.word_cleaner.sub('', w).strip() for w in raw_words]
        word_tokens = [w for w in word_tokens if w and len(w) > 1]

        # 철자 분해
        letters = [char for word in word_tokens for char in word]

        return {
            "original": [original],
            "sentences": sentences,
            "words": word_tokens,
            "spell": letters
        }
