# -*- coding: utf-8 -*-
"""
@author: 배준호
"""

import cupy as cp

class Dense:
    def __init__(self, ips, ops, lr=0.001, b1=0.9, b2=0.999, eps=1e-8):
        self.ips, self.ops = ips, ops
        self.lr, self.b1, self.b2, self.eps = lr, b1, b2, eps
        
        self.w = cp.random.normal(0, cp.sqrt(2.0 / (ips + ops)), (ips, ops))
        self.b = cp.zeros(ops)

        self.mw = cp.zeros_like(self.w); self.vw = cp.zeros_like(self.w)
        self.mb = cp.zeros_like(self.b); self.vb = cp.zeros_like(self.b)
        self.t = 0

    def forward(self, x):
        self.x = x.reshape(1, -1) if x.ndim == 1 else x
        return self.x @ self.w + self.b

    def backward(self, d):
        d = d.reshape(1, -1) if d.ndim == 1 else d
        self.descent(d)
        return d @ self.w.T

    def descent(self, d):
        self.t += 1
        self.mw[:] = self.b1 * self.mw + (1 - self.b1) * (dw := self.x.T @ d)
        self.vw[:] = self.b2 * self.vw + (1 - self.b2) * (dw * dw)
        self.mb[:] = self.b1 * self.mb + (1 - self.b1) * (db := cp.mean(d, axis=0))
        self.vb[:] = self.b2 * self.vb + (1 - self.b2) * (db * db)

        bc1, bc2 = 1 - self.b1**self.t, 1 - self.b2**self.t
        self.w -= self.lr * (self.mw / bc1) / (cp.sqrt(self.vw / bc2) + self.eps)
        self.b -= self.lr * (self.mb / bc1) / (cp.sqrt(self.vb / bc2) + self.eps)

class ReLu:
    def forward(self, x):
        self.x = x
        return cp.maximum(x, 0)

    def backward(self, d):
        return d * (self.x > 0)

class Sigmoid:
    def forward(self, x):
        self.y = 1.0 / (1 + cp.exp(-x))
        return self.y

    def backward(self, d):
        return d * (1 - self.y) * self.y

class Softmax:
    def forward(self, x):
        x = x - cp.max(x, axis=1, keepdims=True)  # 안정화
        e = cp.exp(x)
        self.y = e / cp.sum(e, axis=1, keepdims=True)
        return self.y

class MSE:
    def forward(self, y_pred, y_true):
        self.diff = y_pred - y_true
        return cp.mean(self.diff ** 2)

    def backward(self):
        return 2 * self.diff / self.diff.shape[0]

