# -*- coding: utf-8 -*-
"""
@author: 배준호
"""

import cupy as cp

class Dense:
    def __init__(self, ips, ops, lr=0.0005, b1=0.9, b2=0.999, eps=1e-8):
        self.ips, self.ops = ips, ops
        self.lr, self.b1, self.b2, self.eps = lr, b1, b2, eps
        
        self.w = cp.random.normal(0, cp.sqrt(2.0 / (ips + ops)), (ips, ops))
        self.b = cp.zeros(ops)

        self.mw = cp.zeros_like(self.w); self.vw = cp.zeros_like(self.w)
        self.mb = cp.zeros_like(self.b); self.vb = cp.zeros_like(self.b)
        self.t = 0

    def forward(self, x):
        self.x = x.reshape(1, -1) if x.ndim == 1 else x
        return self.x @ self.w + self.b

    def backward(self, d):
        d = d.reshape(1, -1) if d.ndim == 1 else d
        self.descent(d)
        return d @ self.w.T

    def descent(self, d):
        self.t += 1
        self.mw[:] = self.b1 * self.mw + (1 - self.b1) * (dw := self.x.T @ d)
        self.vw[:] = self.b2 * self.vw + (1 - self.b2) * (dw * dw)
        self.mb[:] = self.b1 * self.mb + (1 - self.b1) * (db := cp.mean(d, axis=0))
        self.vb[:] = self.b2 * self.vb + (1 - self.b2) * (db * db)

        bc1, bc2 = 1 - self.b1**self.t, 1 - self.b2**self.t
        self.w -= self.lr * (self.mw / bc1) / (cp.sqrt(self.vw / bc2) + self.eps)
        self.b -= self.lr * (self.mb / bc1) / (cp.sqrt(self.vb / bc2) + self.eps)

class ReLu:
    def forward(self, x):
        self.x = x
        return cp.maximum(x, 0)

    def backward(self, d):
        return d * (self.x > 0)

class Sigmoid:
    def forward(self, x):
        self.y = 1.0 / (1 + cp.exp(-x))
        return self.y

    def backward(self, d):
        return 2 * d * (1 - self.y) * self.y

class Softmax:
    def forward(self, x):
        x = x - cp.max(x, axis=1, keepdims=True)  # 안정화
        e = cp.exp(x)
        self.y = e / cp.sum(e, axis=1, keepdims=True)
        return self.y

class MSE:
    def forward(self, y_pred, y_true):
        self.diff = y_pred - y_true
        return cp.mean(self.diff ** 2)

    def backward(self):
        return 2 * self.diff / self.diff.shape[0]

class BatchNorm:
    def __init__(self, dim, eps=1e-5, mom=0.9):
        self.eps, self.mom, self.dim = eps, mom, dim
        self.gamma, self.beta = cp.ones((1, dim)), cp.zeros((1, dim))
        self.rm, self.rv = cp.zeros((1, dim)), cp.ones((1, dim))
        self.mg, self.vg = cp.zeros((1, dim)), cp.zeros((1, dim))
        self.mb, self.vb = cp.zeros((1, dim)), cp.zeros((1, dim))
        self.t = 0

    def forward(self, x, train=True):
        if train:
            mean = cp.mean(x, axis=0, keepdims=True)
            var = cp.var(x, axis=0, keepdims=True)
            xc = x - mean
            std_inv = 1 / cp.sqrt(var + self.eps)
            self.x_hat = xc * std_inv
            self.dxh = (xc, std_inv, x.shape[0])
            self.rm = self.mom * self.rm + (1 - self.mom) * mean
            self.rv = self.mom * self.rv + (1 - self.mom) * var
            return self.gamma * self.x_hat + self.beta
        else:
            x_hat = (x - self.rm) / cp.sqrt(self.rv + self.eps)
            return self.gamma * x_hat + self.beta

    def backward(self, delta):
        xc, std_inv, N = self.dxh
        self.dgamma = cp.sum(delta * self.x_hat, axis=0, keepdims=True)
        self.dbeta = cp.sum(delta, axis=0, keepdims=True)

        dx_hat = delta * self.gamma
        dvar = cp.sum(dx_hat * xc, axis=0, keepdims=True) * -0.5 * std_inv**3
        dmean = cp.sum(dx_hat * -std_inv, axis=0, keepdims=True) + dvar * cp.mean(-2 * xc, axis=0, keepdims=True)
        return dx_hat * std_inv + dvar * 2 * xc / N + dmean / N

    def descent(self, lr=0.001, b1=0.9, b2=0.999):
        self.t += 1
        for p, g, m, v in [(self.gamma, self.dgamma, self.mg, self.vg), (self.beta, self.dbeta, self.mb, self.vb)]:
            m[:] = b1 * m + (1 - b1) * g
            v[:] = b2 * v + (1 - b2) * (g ** 2)
            m_hat = m / (1 - b1 ** self.t)
            v_hat = v / (1 - b2 ** self.t)
            p -= lr * m_hat / (cp.sqrt(v_hat) + self.eps)
