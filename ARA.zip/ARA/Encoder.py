# -*- coding: utf-8 -*-
"""
@author: 배준호
"""
from Layer import Dense, ReLu, Sigmoid, Softmax
import cupy as cp
import pickle

class Encoder:
    def __init__(self, buffer):
        self.totalNet = [
            Dense(2048, 1024),
            ReLu(),
            Dense(1024, 256),
            Sigmoid()
        ]

        self.paragraphNet = [
            Dense(1024 * 4, 1024),
            Sigmoid(),
            Dense(1024, 512),
            ReLu()
        ]

        self.sentenceNet = [
            Dense(1024 * 4, 1024),
            Sigmoid(),
            Dense(1024, 512),
            ReLu()
        ]

        self.wordsNet = [
            Dense(1408 * 4, 1024),
            Sigmoid(),
            Dense(1024, 512),
            ReLu()
        ]

        self.spellsNet = [
            Dense(128, 1024),
            Sigmoid(),
            Dense(1024, 512),
            ReLu()
        ]
        
        self.size = 4
        self.connection = buffer
        
    def forward(self, buffedInput):#입력으로 사전에서 translate되고 버퍼된 데이터가 들어온다. 즉, 여기서는 신경망만
        pragIp, sentIp, wordIp, spellIp = self.connection.split(
                                            buffedInput, [1024 * 4, 1024 * 4, 1408 * 4, 128])
        for idx in range(self.size):
            pragIp = self.paragraphNet[idx].forward(pragIp)
            sentIp = self.sentenceNet[idx].forward(sentIp)
            wordIp = self.wordsNet[idx].forward(wordIp)
            spellIp = self.spellsNet[idx].forward(spellIp)
            
        totalIp = self.connection.concat([pragIp, sentIp, wordIp, spellIp])
        
        for net in self.totalNet:
            totalIp = net.forward(totalIp)
            
        self.op = totalIp
        
        return totalIp
    
    def output(self, softN=16, isFlat = False):
        y = self.op.reshape(-1, softN)
        y = Softmax().forward(y)
        
        return y.ravel() if isFlat else y

    def backward(self, delta):
        for layer in reversed(self.totalNet):
            delta = layer.backward(delta)

        pragIp, sentIp, wordIp, spellIp = self.connection.split(
                                                delta, [512, 512, 512, 512])
        for idx in reversed(range(self.size)):
            pragIp = self.paragraphNet[idx].backward(pragIp)
            sentIp = self.sentenceNet[idx].backward(sentIp)
            wordIp = self.wordsNet[idx].backward(wordIp)
            spellIp = self.spellsNet[idx].backward(spellIp)

    def save(self, path):
        nets = self.totalNet + self.paragraphNet + self.sentenceNet + self.wordsNet + self.spellsNet
        self._save_weights(nets, path)
    
    def load(self, path):
        nets = self.totalNet + self.paragraphNet + self.sentenceNet + self.wordsNet + self.spellsNet
        self._load_weights(nets, path)

    def _save_weights(self, nets, filename):
        weights = []
        for net in nets:
            if isinstance(net, Dense):
                weights.append((
                    cp.asnumpy(net.w),
                    cp.asnumpy(net.b)
                ))
        with open(filename, 'wb') as f:
            pickle.dump(weights, f)
    
    def _load_weights(self, nets, filename):
        with open(filename, 'rb') as f:
            weights = pickle.load(f)
    
        idx = 0
        for net in nets:
            if isinstance(net, Dense):
                w, b = weights[idx]
                net.w = cp.asarray(w)
                net.b = cp.asarray(b)
                idx += 1


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            