# -*- coding: utf-8 -*-
"""
@author: 배준호
"""
import cupy as cp
import numpy as np

class ARA:
    def __init__(self, encoder, decoder, dictManager, buffer):
        self.encoder = encoder
        self.decoder = decoder
        self.dicts = dictManager
        self.buffer = buffer
        self.last_loss = None

    def train(self, text):
        para, sent, word, spell = self.dicts.translate(text)
    
        self.buffer.push(para, 2048, 4)
        self.buffer.push(sent, 2048, 4)
        self.buffer.push(word, 2048, 2)
        self.buffer.push(spell, 128, 1)
    
        batch_progress = self.buffer.size()
        batch = self.buffer.get_batch()
        
        if batch is not None:
            encoded = self.encoder.forward(batch)
            decoded, loss = self.decoder.forward(encoded, batch)

            grad = self.decoder.backward()
            self.encoder.backward(grad)
            self.buffer.flush()
#            print()
#            print(np.array2string(cp.asnumpy(encoded[0]), threshold=np.inf))
#            print(np.array2string(cp.asnumpy(decoded[0][1024:1200]), threshold=np.inf))
            return loss, 0
            
        return None, batch_progress

    def predict(self, text, softN=16, isFlat=False):
        para, sent, word, spell = self.dicts.translate(text)
    
        self.buffer.set_batch(1)
        self.buffer.push(para, 2048, 4)
        self.buffer.push(sent, 2048, 4)
        self.buffer.push(word, 2048, 2)
        self.buffer.push(spell, 128, 1)
    
        batch = self.buffer.get_batch()
        if batch is None:
            return None
    
        self.encoder.forward(batch)
        self.buffer.flush()
        
        return self.encoder.output(softN=softN, isFlat=isFlat)

    def save(self, prefix="ara"):
        self.encoder.save(f"{prefix}_encoder.pkl")
        self.decoder.save(f"{prefix}_decoder.pkl")
        self.dicts.save(f"{prefix}_dict")

    def load(self, prefix="ara"):
        self.encoder.load(f"{prefix}_encoder.pkl")
        self.decoder.load(f"{prefix}_decoder.pkl")
        self.dicts.load(f"{prefix}_dict")
