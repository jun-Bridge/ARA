# -*- coding: utf-8 -*-
"""
@author: 배준호
"""

from ARA import ARA
from Encoder import Encoder
from Decoder import Decoder
from DictManager import DictManager
from ConnectLayer import ConnectLayer
from Train import Train

import os


def main():
    data_folder = "E:/aclImdb_v1/aclImdb/train/pos"
    buffer = ConnectLayer(dic_size=4, batch_size=10)
    encoder = Encoder(buffer)
    decoder = Decoder(buffer)
    dicts = DictManager()

    ara = ARA(encoder, decoder, dicts, buffer)

    if os.path.exists("ara_model_encoder.pkl"):
        print("이전 모델을 불러옵니다.")
        ara.load("ara_model")

    trainer = Train(ara, data_folder, chunk_size=4)
    trainer.run(epoch=10, offset=0, filesize=50, isShuffle=True, isSlipped=True)

if __name__ == "__main__":
    main()
    
    
# 인덱스_이름.txt 형태의 파일을 filesize만큼 읽어온다.
# 그 문장 리스트를 문장부호 단위로 분해한 다음, chunk_size 크기로 묶어 한 줄을 만든다
# 한 줄씩 사전에 읽히고 버퍼에 넣는다. batch_size만큼 읽혀 버퍼가 가득 차면 한 번의 훈련을 진행한다.
# epoch을 통해 파일을 학습시키며, offset 인덱스부터 읽어온다. 
# isSlipped가 True일 경우 한 번의 에폭마다 파일 입력 윈도우를 옆으로 이동시켜 다른 파일 하나를 더 읽어온다.
# 이를 통해 점진적인 희석 학습이 가능하다.


 
#음, 지금... 벡터 평균 만으로는 너무 클 수 있다. 생각해보니 그럴지도.